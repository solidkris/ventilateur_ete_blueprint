# Blueprint – Ventilateur intelligent été

## Contenu du ZIP
- blueprints/automation/christophe/fan_summer_control.yaml
- packages/ventilateurs.yaml

## Installation
1. Copier le fichier `fan_summer_control.yaml` dans `config/blueprints/automation/christophe/`
2. Copier `ventilateurs.yaml` dans `config/packages/`
3. Redémarrer Home Assistant ou recharger les automatisations
